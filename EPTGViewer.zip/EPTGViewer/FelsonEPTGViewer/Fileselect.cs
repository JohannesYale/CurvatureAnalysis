﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Telerik.WinControls.UI;

namespace FelsonEPTGViewer
{
    internal class Fileselect
    {
        public static List<ImageSet> LoadImageSets()
        {
            List<ImageSet> imageSets = new List<ImageSet>();
            List<ImageSet> doubledImageSet = new List<ImageSet>();
            try
            {
                List<string> nonloaded = new List<string>();
                using (var fbd = new FolderBrowserDialog())
                {
                    DialogResult result = fbd.ShowDialog();

                    if (result == DialogResult.OK && !string.IsNullOrWhiteSpace(fbd.SelectedPath))
                    {
                        Viewer.directory = fbd.SelectedPath;
                        if (!File.Exists(Viewer.directory + @"\MeasurementResult.txt"))
                        {
                            using (FileStream file = File.Create(Viewer.directory + @"\MeasurementResult.txt"))
                            {
                                string header = "FileName;Evaluator;EPTG;EPTP;TransitionScale;TimeStamp;Hide" + Environment.NewLine;
                                file.Write(Encoding.UTF8.GetBytes(header),
                                    0, Encoding.UTF8.GetByteCount(header));
                            }

                        }
                        if(!Directory.Exists(Viewer.directory + @"\Screenshots"))
                        {
                            Directory.CreateDirectory(Viewer.directory + @"\Screenshots");
                        }
                        string[] filesAP = Directory.GetFiles(Path.Combine(Viewer.directory, "APView"), "*.png");
                        string[] filesRidge = Directory.GetFiles(Path.Combine(Viewer.directory, "Ridge"), "*.png");
                        string[] filesTransition = Directory.GetFiles(Path.Combine(Viewer.directory, "Transition"), "*.png");

                        int errors = 0;
                        foreach (string AP in filesAP)
                        {
                            string caseNumber = Path.GetFileName(AP).Split('_')[0] + "_" + Path.GetFileName(AP).Split('_')[1];

                            try
                            {
                                string transition = filesTransition.First(x => Path.GetFileName(x).Split('_')[0] +"_" + Path.GetFileName(x).Split('_')[1] == caseNumber);
                                string ridge = filesRidge.First(x => Path.GetFileName(x).Split('_')[0] + "_" + Path.GetFileName(x).Split('_')[1] == caseNumber);

                                imageSets.Add(new ImageSet(caseNumber, System.Drawing.Image.FromFile(AP), System.Drawing.Image.FromFile(ridge), System.Drawing.Image.FromFile(transition)));
                            }
                            catch (Exception ex)
                            {
                                nonloaded.Add(caseNumber);
                                errors++;
                            }
                        }
                        if (errors > 0)
                        {
                            string nonloads = "";
                            foreach(var nonload in nonloaded)
                            {
                                nonloads += nonload + ";";
                            }
                            MessageBox.Show(errors.ToString() + " image(s) were not loaded." + nonloads);
                        }
                        
                       
                        foreach (var imageSet in imageSets)
                        {
                            doubledImageSet.Add(imageSet);
                            doubledImageSet.Add(new ImageSet(imageSet, false));
                        }

                        Random rng = new Random();
                        int n = doubledImageSet.Count;

                        while (n > 1)
                        {
                            n--;
                            int k = rng.Next(n + 1);
                            ImageSet value = doubledImageSet[k];
                            doubledImageSet[k] = doubledImageSet[n];
                            doubledImageSet[n] = value;
                        }
                    }
                    else
                    {
                        MessageBox.Show("Choosing folder not successful");
                        return null;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Choosing folder not successful");
                return null;
            }

            return doubledImageSet;
        }
    }

    internal enum Side
    {
        Left = 0, Right = 1, Undefined = 99
    }

    internal class ImageSet
    {

        /// <summary>
        /// The case number of the imageset
        /// </summary>
        internal string CaseNumber;
        /// <summary>
        /// Decide whether ridges and transitions should be hidden
        /// </summary>
        internal bool HideImages = true;
        /// <summary>
        /// APView of the distal femur
        /// </summary>
        internal System.Drawing.Image APView;
        /// <summary>
        /// Map highligthing the ridges
        /// </summary>
        internal System.Drawing.Image Ridge;
        /// <summary>
        /// Map highlighting the transition point
        /// </summary>
        internal System.Drawing.Image Transition;

        public ImageSet(string caseNumber, System.Drawing.Image apView, System.Drawing.Image ridge, System.Drawing.Image transition, bool hideImages = true)
        {
            CaseNumber = caseNumber;
            APView = apView;
            Ridge = ridge;
            Transition = transition;
            HideImages = hideImages;
        }
        public ImageSet(ImageSet imageSet, bool hideImages)
        {
            CaseNumber = imageSet.CaseNumber;
            APView = imageSet.APView;
            Ridge = imageSet.Ridge;
            Transition = imageSet.Transition;
            HideImages = hideImages;
        }
    }
}
