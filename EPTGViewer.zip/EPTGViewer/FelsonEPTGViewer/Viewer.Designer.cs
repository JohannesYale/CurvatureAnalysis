﻿namespace FelsonEPTGViewer
{
    partial class Viewer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            radPanel1 = new Telerik.WinControls.UI.RadPanel();
            pBtransition = new Telerik.WinControls.UI.RadPictureBox();
            pBridges = new Telerik.WinControls.UI.RadPictureBox();
            pBAP = new Telerik.WinControls.UI.RadPictureBox();
            buttons = new Telerik.WinControls.UI.RadPanel();
            btnRedo = new Telerik.WinControls.UI.RadButton();
            lblImages = new Telerik.WinControls.UI.RadLabel();
            lbl1 = new Telerik.WinControls.UI.RadLabel();
            btnLoad = new Telerik.WinControls.UI.RadButton();
            btnConfirm = new Telerik.WinControls.UI.RadButton();
            btnReset = new Telerik.WinControls.UI.RadButton();
            btnTransition = new Telerik.WinControls.UI.RadButton();
            tBName = new Telerik.WinControls.UI.RadTextBox();
            ((System.ComponentModel.ISupportInitialize)radPanel1).BeginInit();
            radPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pBtransition).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pBridges).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pBAP).BeginInit();
            ((System.ComponentModel.ISupportInitialize)buttons).BeginInit();
            buttons.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)btnRedo).BeginInit();
            ((System.ComponentModel.ISupportInitialize)lblImages).BeginInit();
            ((System.ComponentModel.ISupportInitialize)lbl1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)btnLoad).BeginInit();
            ((System.ComponentModel.ISupportInitialize)btnConfirm).BeginInit();
            ((System.ComponentModel.ISupportInitialize)btnReset).BeginInit();
            ((System.ComponentModel.ISupportInitialize)btnTransition).BeginInit();
            ((System.ComponentModel.ISupportInitialize)tBName).BeginInit();
            ((System.ComponentModel.ISupportInitialize)this).BeginInit();
            SuspendLayout();
            // 
            // radPanel1
            // 
            radPanel1.Anchor = System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left;
            radPanel1.Controls.Add(pBtransition);
            radPanel1.Controls.Add(pBridges);
            radPanel1.Controls.Add(pBAP);
            radPanel1.Location = new System.Drawing.Point(0, 12);
            radPanel1.Name = "radPanel1";
            radPanel1.Size = new System.Drawing.Size(1170, 485);
            radPanel1.TabIndex = 0;
            // 
            // pBtransition
            // 
            pBtransition.Dock = System.Windows.Forms.DockStyle.Right;
            pBtransition.Location = new System.Drawing.Point(795, 0);
            pBtransition.Name = "pBtransition";
            pBtransition.Size = new System.Drawing.Size(375, 485);
            pBtransition.TabIndex = 1;
            // 
            // pBridges
            // 
            pBridges.Dock = System.Windows.Forms.DockStyle.Left;
            pBridges.Location = new System.Drawing.Point(0, 0);
            pBridges.Name = "pBridges";
            pBridges.Size = new System.Drawing.Size(398, 485);
            pBridges.TabIndex = 0;
            // 
            // pBAP
            // 
            pBAP.Location = new System.Drawing.Point(398, 0);
            pBAP.Name = "pBAP";
            pBAP.Size = new System.Drawing.Size(401, 485);
            pBAP.TabIndex = 2;
            pBAP.Paint += pBAP_Paint;
            pBAP.MouseDown += pBAP_MouseDown;
            // 
            // buttons
            // 
            buttons.Controls.Add(btnRedo);
            buttons.Controls.Add(lblImages);
            buttons.Controls.Add(lbl1);
            buttons.Controls.Add(btnLoad);
            buttons.Controls.Add(btnConfirm);
            buttons.Controls.Add(btnReset);
            buttons.Controls.Add(btnTransition);
            buttons.Controls.Add(tBName);
            buttons.Dock = System.Windows.Forms.DockStyle.Bottom;
            buttons.Location = new System.Drawing.Point(0, 503);
            buttons.Name = "buttons";
            buttons.Size = new System.Drawing.Size(1170, 100);
            buttons.TabIndex = 1;
            // 
            // btnRedo
            // 
            btnRedo.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            btnRedo.Location = new System.Drawing.Point(1000, 5);
            btnRedo.Name = "btnRedo";
            btnRedo.Size = new System.Drawing.Size(167, 67);
            btnRedo.TabIndex = 7;
            btnRedo.Text = "Redo Screenshots";
            btnRedo.Click += btnRedo_Click;
            // 
            // lblImages
            // 
            lblImages.Location = new System.Drawing.Point(176, 7);
            lblImages.Name = "lblImages";
            lblImages.Size = new System.Drawing.Size(76, 18);
            lblImages.TabIndex = 6;
            lblImages.Text = "Images: 0 of 0";
            // 
            // lbl1
            // 
            lbl1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            lbl1.Location = new System.Drawing.Point(553, 72);
            lbl1.Name = "lbl1";
            lbl1.Size = new System.Drawing.Size(79, 25);
            lbl1.TabIndex = 5;
            lbl1.Text = "radLabel1";
            lbl1.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            // 
            // btnLoad
            // 
            btnLoad.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            btnLoad.Location = new System.Drawing.Point(12, 7);
            btnLoad.Name = "btnLoad";
            btnLoad.Size = new System.Drawing.Size(158, 43);
            btnLoad.TabIndex = 4;
            btnLoad.Text = "Load Images";
            btnLoad.Click += btnLoad_Click;
            // 
            // btnConfirm
            // 
            btnConfirm.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            btnConfirm.Location = new System.Drawing.Point(521, 5);
            btnConfirm.Name = "btnConfirm";
            btnConfirm.Size = new System.Drawing.Size(152, 47);
            btnConfirm.TabIndex = 3;
            btnConfirm.Text = "Confirm";
            btnConfirm.Visible = false;
            btnConfirm.Click += btnConfirm_Click;
            // 
            // btnReset
            // 
            btnReset.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            btnReset.Location = new System.Drawing.Point(679, 5);
            btnReset.Name = "btnReset";
            btnReset.Size = new System.Drawing.Size(176, 47);
            btnReset.TabIndex = 2;
            btnReset.Text = "Reset";
            btnReset.Visible = false;
            btnReset.Click += btnReset_Click;
            // 
            // btnTransition
            // 
            btnTransition.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            btnTransition.Location = new System.Drawing.Point(339, 5);
            btnTransition.Name = "btnTransition";
            btnTransition.Size = new System.Drawing.Size(176, 47);
            btnTransition.TabIndex = 1;
            btnTransition.Text = "No Transition Point";
            btnTransition.Visible = false;
            btnTransition.Click += btnTransition_Click;
            // 
            // tBName
            // 
            tBName.Location = new System.Drawing.Point(12, 64);
            tBName.Name = "tBName";
            tBName.Size = new System.Drawing.Size(174, 24);
            tBName.TabIndex = 0;
            // 
            // Viewer
            // 
            AutoScaleBaseSize = new System.Drawing.Size(7, 15);
            AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            ClientSize = new System.Drawing.Size(1170, 603);
            Controls.Add(buttons);
            Controls.Add(radPanel1);
            Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            Name = "Viewer";
            Text = "EPTG_EPTP_Measurer";
            ((System.ComponentModel.ISupportInitialize)radPanel1).EndInit();
            radPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pBtransition).EndInit();
            ((System.ComponentModel.ISupportInitialize)pBridges).EndInit();
            ((System.ComponentModel.ISupportInitialize)pBAP).EndInit();
            ((System.ComponentModel.ISupportInitialize)buttons).EndInit();
            buttons.ResumeLayout(false);
            buttons.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)btnRedo).EndInit();
            ((System.ComponentModel.ISupportInitialize)lblImages).EndInit();
            ((System.ComponentModel.ISupportInitialize)lbl1).EndInit();
            ((System.ComponentModel.ISupportInitialize)btnLoad).EndInit();
            ((System.ComponentModel.ISupportInitialize)btnConfirm).EndInit();
            ((System.ComponentModel.ISupportInitialize)btnReset).EndInit();
            ((System.ComponentModel.ISupportInitialize)btnTransition).EndInit();
            ((System.ComponentModel.ISupportInitialize)tBName).EndInit();
            ((System.ComponentModel.ISupportInitialize)this).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Telerik.WinControls.UI.RadPanel radPanel1;
        private Telerik.WinControls.UI.RadPanel buttons;
        private Telerik.WinControls.UI.RadPictureBox pBAP;
        private Telerik.WinControls.UI.RadPictureBox pBtransition;
        private Telerik.WinControls.UI.RadPictureBox pBridges;
        private Telerik.WinControls.UI.RadButton btnTransition;
        private Telerik.WinControls.UI.RadButton btnReset;
        private Telerik.WinControls.UI.RadTextBox tBName;
        private Telerik.WinControls.UI.RadButton btnConfirm;
        private Telerik.WinControls.UI.RadButton btnLoad;
        private Telerik.WinControls.UI.RadLabel lbl1;
        private Telerik.WinControls.UI.RadLabel lblImages;
        private Telerik.WinControls.UI.RadButton btnRedo;
    }
}