﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Numerics;
using System.Text;
using System.Windows.Forms;


namespace FelsonEPTGViewer
{
    public partial class Viewer : Telerik.WinControls.UI.RadForm
    {
        internal static Viewer thisForm;
        internal List<ImageSet> ImageSets { get; set; } = new List<ImageSet>();
        Process Process { get; set; }
        List<System.Drawing.Point> points = new List<Point>();
        System.Drawing.Point condyle1;
        Point condyle2;
        Point trochlea;
        Point endpoint;
        Point transitionPoint;
        Point ridge1;
        Point ridge2;
        double slopeNormal;
        double angle;
        double eptp;
        double transitionscale;
        internal static string directory;

        internal int ImageIndex = 0;
        public Viewer()
        {
            InitializeComponent();
            thisForm = this;
            Process = new Process();
            Process.StateChanged += Process_StateChanged;
            lbl1.Text = "Please put your name in an load the test files";
        }

        private void Process_StateChanged(object sender, EventArgs e)
        {
            switch (Process.CurrentState)
            {
                case ProcessState.Condyles:
                    if (ImageIndex < ImageSets.Count)
                    {
                        pBAP.Invalidate();
                        pBAP_Paint(pBAP, new PaintEventArgs(pBAP.CreateGraphics(), new Rectangle()));
                        btnReset.Visible = true;
                        pBAP.Image = ImageSets[ImageIndex].APView;
                        if (!ImageSets[ImageIndex].HideImages)
                        {
                            pBridges.Image = ImageSets[ImageIndex].Ridge;
                            pBtransition.Image = ImageSets[ImageIndex].Transition;
                        }
                        else
                        {
                            pBridges.Image = null;
                            pBtransition.Image = null;
                        }
                        btnConfirm.Visible = false;
                        btnLoad.Visible = false;
                        lbl1.Text = "Please click on the most distal point of the medial and lateral femoral condyles.";
                        lblImages.Text = "Images " + ImageIndex + " of " + ImageSets.Count + " done";
                    }
                    else
                    {
                        MessageBox.Show("Congrats you are finished.");
                        Application.Exit();
                    }
                    break;

                case ProcessState.TrochleaGrove:
                    lbl1.Text = "Please click on the most distal point within the trochlea groove.";
                    break;

                case ProcessState.Endoint:
                    lbl1.Text = "Please click on the lateral and medial ridge of the proximal trochlea.";
                    break;

                case ProcessState.TransitionPoint:
                    lbl1.Text = "Please click on the transition point, if there is none, please click on No Trainsition Point.";
                    break;
                case ProcessState.Angles:
                    btnConfirm.Visible = true;
                    break;
            }
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            ImageSets = Fileselect.LoadImageSets();
            if (ImageSets != null)
            {
                Process.MoveNext(Command.Begin);
            }
        }

        private void pBAP_MouseDown(object sender, MouseEventArgs e)
        {
            switch (Process.CurrentState)
            {
                case (ProcessState.Condyles):

                    if (points.Count < 2)
                    {
                        points.Add(new Point(e.Location.X, e.Location.Y));
                        btnReset.Visible = true;
                    }
                    if (points.Count == 2)
                    {
                        condyle1 = points[0];
                        condyle2 = points[1];
                        points.Clear();
                        Process.MoveNext(Command.Confirm);
                    }
                    break;

                case (ProcessState.TrochleaGrove):
                    if (points.Count < 1)
                    {
                        points.Add(new Point(e.Location.X, e.Location.Y));
                    }
                    if (points.Count == 1)
                    {
                        try
                        {
                            trochlea = points[0];
                            points.Clear();
                            if ((condyle2.Y - condyle1.Y) != 0)
                            {
                                slopeNormal = ((double)(condyle2.X - condyle1.X)) / -((double)(condyle2.Y - condyle1.Y));
                                Point first = new Point(trochlea.X + 50, Convert.ToInt32(trochlea.Y + slopeNormal * 50));
                                Point second = new Point(trochlea.X - 50, Convert.ToInt32(trochlea.Y - slopeNormal * 50));
                            }
                            else
                            {
                                Point first = new Point(trochlea.X, Convert.ToInt32(trochlea.Y +50));
                                Point second = new Point(trochlea.X, Convert.ToInt32(trochlea.Y - 50));
                                slopeNormal = 10000;
                            }
                           
                            Process.MoveNext(Command.Confirm);
                        }
                        catch
                        {
                            MessageBox.Show("Division through zero, please restart.");
                            Restart();
                        }
                    }
                    break;
                case (ProcessState.Endoint):

                    if (points.Count < 2)
                    {
                        points.Add(new Point(e.Location.X, e.Location.Y));
                    }
                    if (points.Count == 2)
                    {
                        endpoint = new System.Drawing.Point((points[0].X + points[1].X) / 2, (points[0].Y + points[1].Y) / 2);
                        try
                        {
                            ridge1 = points[0];
                            ridge2 = points[1];
                            var slope = ((double)(endpoint.Y - trochlea.Y)) / ((double)(endpoint.X - trochlea.X));
                            if (!double.IsNaN(slope))
                            {
                                angle = Math.Abs(Math.Atan((slopeNormal - slope) / (1 + slope * slopeNormal)) * 180 / Math.PI);
                            }
                            else
                            {
                                
                                angle = 90 - Math.Abs(Math.Atan(slopeNormal) * 180 / Math.PI);
                            }
                            Process.MoveNext(Command.Confirm);
                            points.Clear();
                            btnTransition.Visible = true;
                            if (angle == double.NaN)
                            {
                                MessageBox.Show("Division through 0 occured (coincidence), please redo.");
                                Restart();
                            }
                        }
                        catch
                        {
                            MessageBox.Show("Division through zero occured, please try again.");
                            Restart();
                        }
                    }
                    break;
                case (ProcessState.TransitionPoint):

                    transitionPoint = new Point(e.Location.X, e.Location.Y);
                    try
                    {
                        Vector2 transTroch = new Vector2(transitionPoint.X - trochlea.X, transitionPoint.Y - trochlea.Y);
                        Vector2 transEndPoint = new Vector2(transitionPoint.X - endpoint.X, transitionPoint.Y - endpoint.Y);
                        Vector2 trochEndpoint = new Vector2(endpoint.X - trochlea.X, endpoint.Y - trochlea.Y);
                        eptp = 180 - Math.Acos(Vector2.Dot(Vector2.Normalize(transTroch), Vector2.Normalize(transEndPoint))) * 180 / Math.PI;
                        double A = transTroch.Length();
                        double B = transEndPoint.Length();
                        double C = trochEndpoint.Length();

                        lbl1.Text = "EPTG: " + angle.ToString("N2") + " Degree."+ " EPTP: " + eptp.ToString("N2") + " Degree.";
                        btnTransition.Visible = false;
                        Process.MoveNext(Command.Confirm);
                    }
                    catch
                    {
                        MessageBox.Show("Division through zero occured, please try again.");
                        Restart();
                    }
                    break;
            }
            pBAP.Invalidate();
        }

        private void Restart()
        {
            points.Clear();
            Process.CurrentState = ProcessState.Condyles;
        }

        void DrawCircle(Graphics g, Brush brush, Point center, float radius)
        {
            float centerX = center.X;
            float centerY = center.Y;

            g.FillEllipse(brush, centerX - radius, centerY - radius,
                          radius + radius, radius + radius);
        }

        private void pBAP_Paint(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            if (Process.CurrentState == ProcessState.Condyles)
            {
                if (points.Count == 1)
                {
                    Brush p = new SolidBrush(Color.Blue);
                    DrawCircle(g, p, points[0], 6);
                }
            }

            if (Process.CurrentState == ProcessState.TrochleaGrove)
            {
                Brush p = new SolidBrush(Color.Blue);
                DrawCircle(g, p, condyle1, 6);
                DrawCircle(g, p, condyle2, 6);
                Pen m = new Pen(Color.Green);
                g.DrawLine(m, condyle1, condyle2);
            }

            if (Process.CurrentState == ProcessState.Endoint)
            {
                Brush b = new SolidBrush(Color.Blue);
                DrawCircle(g, b, condyle1, 6);
                DrawCircle(g, b, condyle2, 6);
                DrawCircle(g, b, trochlea, 6);
                Pen p = new Pen(Color.Red);
                Point first;
                Point second;
                if ((condyle2.Y - condyle1.Y) != 0)
                {
                    first = new Point(trochlea.X + 50, Convert.ToInt32(trochlea.Y + slopeNormal * 50));
                    second = new Point(trochlea.X - 50, Convert.ToInt32(trochlea.Y - slopeNormal * 50));
                }
                else
                {
                    first = new Point(trochlea.X, Convert.ToInt32(trochlea.Y + 200));
                    second = new Point(trochlea.X, Convert.ToInt32(trochlea.Y - 200));
                }
                g.DrawLine(p, first, second);
                p = new Pen(Color.Green);
                g.DrawLine(p, condyle1, condyle2);

                if (points.Count != 0)
                {
                    Brush gr = new SolidBrush(Color.Green);
                    DrawCircle(g, gr, points[0], 6);
                }
            }

            if (Process.CurrentState == ProcessState.TransitionPoint)
            {
                Brush b = new SolidBrush(Color.Blue);
                DrawCircle(g, b, condyle1, 6);
                DrawCircle(g, b, condyle2, 6);
                DrawCircle(g, b, trochlea, 6);
                DrawCircle(g, b, endpoint, 6);
                Brush gr = new SolidBrush(Color.Green);
                DrawCircle(g, gr, ridge1, 6);
                DrawCircle(g, gr, ridge2, 6);
                Pen p = new Pen(Color.Red);
                Point first;
                Point second;
                if ((condyle2.Y - condyle1.Y) != 0)
                {
                    first = new Point(trochlea.X + 50, Convert.ToInt32(trochlea.Y + slopeNormal * 50));
                    second = new Point(trochlea.X - 50, Convert.ToInt32(trochlea.Y - slopeNormal * 50));
                }
                else
                {
                    first = new Point(trochlea.X, Convert.ToInt32(trochlea.Y + 200));
                    second = new Point(trochlea.X, Convert.ToInt32(trochlea.Y - 200));
                }
                g.DrawLine(p, first, second);
                g.DrawLine(p, endpoint, trochlea);
                p = new Pen(Color.Green);
                g.DrawLine(p, condyle1, condyle2);
            }

            if (Process.CurrentState == ProcessState.Angles)
            {
                Brush b = new SolidBrush(Color.Blue);
                DrawCircle(g, b, condyle1, 6);
                DrawCircle(g, b, condyle2, 6);
                DrawCircle(g, b, trochlea, 6);
                DrawCircle(g, b, endpoint, 6);
                Brush gr = new SolidBrush(Color.Green);
                DrawCircle(g, gr, ridge1, 6);
                DrawCircle(g, gr, ridge2, 6);
                Pen p = new Pen(Color.Red);
                Point first;
                Point second;
                if ((condyle2.Y - condyle1.Y) != 0)
                {
                    first = new Point(trochlea.X + 50, Convert.ToInt32(trochlea.Y + slopeNormal * 50));
                    second = new Point(trochlea.X - 50, Convert.ToInt32(trochlea.Y - slopeNormal * 50));
                }
                else
                {
                    first = new Point(trochlea.X, Convert.ToInt32(trochlea.Y + 200));
                    second = new Point(trochlea.X, Convert.ToInt32(trochlea.Y - 200));
                }
                g.DrawLine(p, first, second);
                g.DrawLine(p, endpoint, trochlea);
                DrawCircle(g, b, transitionPoint, 6);
                p = new Pen(Color.Orange);
                g.DrawLine(p, endpoint, transitionPoint);
                g.DrawLine(p, transitionPoint, trochlea);
                p = new Pen(Color.Green);
                g.DrawLine(p, condyle1, condyle2);
            }
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            if (Process.CurrentState == ProcessState.Angles)
            {
                string line = ImageSets[ImageIndex].CaseNumber + "," + tBName.Text + "," + angle.ToString("N2") + "," + eptp.ToString("N2") + "," + transitionscale.ToString("N2") + "," + DateTime.Now.ToString() +"," + ImageSets[ImageIndex].HideImages.ToString() + Environment.NewLine;
                System.IO.File.AppendAllText(directory + @"\MeasurementResult.txt", line);
                
                var frm = System.Windows.Forms.Form.ActiveForm;
                using (var bmp = new Bitmap(frm.Width, frm.Height))
                {
                    frm.DrawToBitmap(bmp, new Rectangle(0, 0, bmp.Width, bmp.Height));
                    bmp.Save(Path.Combine(directory, @"Screenshots\" + ImageSets[ImageIndex].CaseNumber + "_" + tBName.Text + "_" + ImageSets[ImageIndex].HideImages.ToString()+ ".png"));
                }
                ImageIndex++;
                Process.MoveNext(Command.Confirm);
                
            }
        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            points.Clear();
            Process.CurrentState = ProcessState.Condyles;
            Process_StateChanged(null, EventArgs.Empty);
        }

        private void btnTransition_Click(object sender, EventArgs e)
        {
            if (Process.CurrentState == ProcessState.TransitionPoint)
            {
                eptp = 5;
                transitionscale = 0.05;
                lbl1.Text = "EPTG: " + angle.ToString("N2") + " Degree.";
                Process.MoveNext(Command.Confirm);
            }
        }

        private void btnRedo_Click(object sender, EventArgs e)
        {
            string line = ImageSets[ImageIndex].CaseNumber + "," + tBName.Text + "," + "Redo Screenshots" + "," + DateTime.Now.ToString() + Environment.NewLine;
            File.AppendAllText(directory + @"\MeasurementResult.txt", line);
            ImageIndex++;
            Process.CurrentState = ProcessState.Condyles;
            Process_StateChanged(null, EventArgs.Empty);
        }
    }
}
